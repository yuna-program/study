package hello.upload.controller;

import java.io.File;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/spring")
public class SpringUploadController {
	
	@Value("${file.dir}") // 빈주입
	private String fileDir;
	
	@GetMapping("/upload")
	public String newFile() {
		return "upload-form";
	}
	
	
	// MultipartFile 객체의 주요메서드
	// file.getOriginalFilename() :: 업로드 파일명
	// file.transferTo() :: 파일저장
	
	
	@PostMapping("/upload")
	public String saveFile(@RequestParam("file") MultipartFile file, HttpServletRequest request) throws IllegalStateException, IOException {
		
		log.info("file={}",file);
		log.info("file.getOriginalFilename={}",file.getOriginalFilename());
		log.info("fileDir={}",fileDir);
		 
		if(!file.isEmpty()) {
			String fullPath = fileDir + file.getOriginalFilename();
			file.transferTo(new File(fullPath)); // 파일업로드 수행
		}
		
		return "upload-form";
	}
	
}











