package hello.login.domain.member;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

@Data
public class Member {
	
	private Long id;
	@NotEmpty(message = "아이디 없음")
	private String loginId; // 로그인 아이디
	@NotEmpty
	private String name; // 사용자명
	@NotEmpty
	private String password;
}
